package com.niit.ShoppingCart3.dao;

public class UserDAO
{
	
	public boolean isValidCred(String userid , String pass)
	{
	if(userid.equals("NIIT") && pass.equals("NIIT"))
	{
		return true;
	}
	return false;
}
}

