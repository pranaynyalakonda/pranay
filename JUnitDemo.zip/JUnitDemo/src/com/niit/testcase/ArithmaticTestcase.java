package com.niit.testcase;

import static org.junit.Assert.*;

import org.junit.Test;

import com.niit.Arithmatic;

public class ArithmaticTestcase {
	
	@Test
	public void isEvenTestcase()
	{
		
		Arithmatic a=new Arithmatic();
		assertEquals("Even Test", true, a.isEven(2));
	}

	}


